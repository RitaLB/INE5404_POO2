class Amigo:
    def __init__(self, nome: str, telefone: list, email: str):
        self.__nome = nome
        self.__telefone = telefone
        self.__email = email


    def get_nome(self):
        return self.__nome

    def set_nome(self, nome):
        self.__nome = nome


amigo1 = Amigo("rita", ["333"], "rita@gmail.com")

print(amigo1.get_nome())
    

    