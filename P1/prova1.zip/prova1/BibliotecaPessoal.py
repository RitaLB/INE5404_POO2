from Emprestimo import Emprestimo

class BibliotecaPessoal: 
    def __init__(self, amigos: list, livros: list):
        self.__amigos = amigos
        self.__livros = livros
        self.__emprestimos = []

    def get_amigos(self):
        return self.__amigos

    def set_amigos(self, amigos):
        self.__amigos = amigos

    def get_livros(self):
        return self.__livros

    def set_amigos(self, livros):
        self.__livros = livros

    def get_emprestimos(self):
        return self.__emprestimos

    def set_emprestimos(self, emprestimos):
        self.__emprestimos = emprestimos

    def adiciona_amigo(self, amigo):
        self.__amigos.append(amigo)

    def adiciona_livro(self, livro):
        self.__livros.append(livro)

    def empresta_livro(self, amigo, livro, data):
        self.__emprestimos.append(Emprestimo(amigo, livro, data))
        self.__emprestimos[len(self.__emprestimos)-1].ativo()
        

    def devolve_livro(self, livro, data):
        for emprestimo in self.__emprestimos:
            if emprestimo.get_livro() == livro:
                emprestimo.set_data_fim(data)
                emprestimo.ativo()


    def ver_livros_emprestados(self):
        livros_emprestados_atualmente = []
        for emprestimo in self.__emprestimos:
            if emprestimo.get_observacao() == True:
                livros_emprestados_atualmente.append(emprestimo.get_livro())
                

        print(livros_emprestados_atualmente)

