from Livro import Livro
from Amigo import Amigo
class Emprestimo:
    def __init__(self, amigo, livro, data_inicio):
        self.__amigo = amigo
        self.__livro = livro
        self.__data_inicio = data_inicio
        self.__data_fim = ""
        self.__observacao = False

    def get_amigo(self):
        return self.__amigo

    def set_amigo(self, amigo):
        self.__amigo = amigo

    def get_livro(self):
        return self.__livro.get_titulo()

    def set_livro(self, livro):
        self.__livro = livro

    def get_data_inicio(self):
        return self.__data_inicio

    def set_data_inicio(self, data_inicio):
        self.__data_inicio = data_inicio

    def get_data_fim(self):
        return self.__data_fim

    def set_data_fim(self, data_fim):
        self.__data_fim = data_fim

    def get_observacao(self):
        return self.__observacao

    def set_observacao(self, observacao):
        self.__observacao = observacao

    def ativo(self):
        if self.__observacao == False:
            self.__observacao = True

        else:
            self.__observacao = False
        
        
    

    

    

    
