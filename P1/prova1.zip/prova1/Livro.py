class Livro:
    def __init__(self, titulo, resumo, autor, personagem_principal, genero, faixa_etaria):
        self.__titulo = titulo
        self.__resumo = resumo
        self.__autor = autor
        self.__personagem_principal = personagem_principal
        self.__genero = genero
        self.__faixa_etaria = faixa_etaria


    def get_titulo(self):
        return self.__titulo

    def set_titulo(self, titulo):
        self.__titulo = titulo

    def get_resumo(self):
        return self.__resumo

    def set_resumo(self, resumo):
        self.__resumo = resumo

    def get_autor(self):
        return self.__autor

    def set_autor(self, autor):
        self.__autor = autor

    def get_personagem_principal(self):
        return self.__personagem_principal

    def set_personagem_principal(self, personagem_principal):
        self.__personagem_principal = personagem_principal

    def get_genero(self):
        return self.__genero

    def set_genero(self, genero):
        self.__genero = genero

    def get_faixa_etaria(self):
        return self.__faixa_etaria

    def set_faixa_etaria(self, faixa_etaria):
        self.__faixa_etaria = faixa_etaria


    

    

