"""Crie uma aplicação exemplo que, usando as classes implementadas:

    Cadastre quatro livros
    Cadastre três amigos
    Registre o empréstimo de um livro ao primeiro amigo
    Mostre os livros emprestados
    Registre dois empréstimos de outros livros ao segundo amigo
    Mostre os livros emprestados
    Registre a devolução do livro do primeiro empréstimo
    Mostre os livros emprestados
"""
from Amigo import Amigo
from Emprestimo import Emprestimo
from Livro import Livro
from BibliotecaPessoal import BibliotecaPessoal

livro1 = Livro("João e o pé de feijão", "História de joão e o gigante", "Alguém aí", "João", "Aventura","infantil")
livro2 = Livro("Toda Poesia", "Obra completa do poeta Paulo Leminski", "Paulo Leminski", "Não tem", "Poesia", "adulto")
livro3 = Livro("Obra completa de Chacal", "Reunião de obras do poeta Chacal", "Chacal", "não tem", "Poesia", "adulto")
livro4 = Livro("Branca de Neve", "História da princesa lá", "Anna Paulla", "Branca de neve", "Aventura", "infantil")

amigo1 = Amigo("Pedro", "83993798635", "pedrinho123@gmail.com")
amigo2 = Amigo("Tulio", "982765176", "tulio321@gmail.com")
amigo3 = Amigo("patricia", "8872651725", "patricia11@gmail.com")

minha_biblioteca = BibliotecaPessoal([amigo1, amigo2, amigo3], [livro1, livro2, livro3, livro4])

minha_biblioteca.empresta_livro(amigo1, livro2, "11/02/2022")
minha_biblioteca.ver_livros_emprestados()

minha_biblioteca.empresta_livro(amigo2, livro1, "13/12/2022")
minha_biblioteca.empresta_livro(amigo2, livro3, "13/12/2022")
minha_biblioteca.ver_livros_emprestados()

minha_biblioteca.devolve_livro(livro2, "22/02/2022")
minha_biblioteca.ver_livros_emprestados()




