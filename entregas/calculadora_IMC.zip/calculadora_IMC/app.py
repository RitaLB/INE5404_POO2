from calculadora_controlador import CalculadoraControlador
from pessoa import Pessoa

controle = CalculadoraControlador()
controle.inicia()